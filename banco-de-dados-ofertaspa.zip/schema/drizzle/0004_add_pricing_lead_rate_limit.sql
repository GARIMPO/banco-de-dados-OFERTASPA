ALTER TABLE public.pricing_leads
ADD COLUMN request_fingerprint text NOT NULL DEFAULT '';

CREATE INDEX pricing_leads_rate_limit_idx
ON public.pricing_leads (request_fingerprint, created_at DESC);