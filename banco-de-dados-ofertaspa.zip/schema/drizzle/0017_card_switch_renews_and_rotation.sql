ALTER TABLE public.cards ADD COLUMN rotate_images boolean NOT NULL DEFAULT false;
CREATE OR REPLACE FUNCTION public.cards_touch_image_changed()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF NEW.image_url IS DISTINCT FROM OLD.image_url AND NEW.image_url IS NOT NULL THEN
    NEW.image_changed_at := now();
  END IF;
  IF NEW.show_on_home AND NOT OLD.show_on_home THEN
    NEW.image_changed_at := now();
  END IF;
  RETURN NEW;
END $$;