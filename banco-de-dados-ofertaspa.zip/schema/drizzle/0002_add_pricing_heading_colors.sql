ALTER TABLE public.pricing_page_settings
ADD COLUMN page_title_color text NOT NULL DEFAULT '',
ADD COLUMN page_subtitle_color text NOT NULL DEFAULT '';

ALTER TABLE public.pricing_page_settings
ADD CONSTRAINT pricing_page_title_color_format
CHECK (page_title_color = '' OR page_title_color ~ '^#[0-9A-Fa-f]{6}$'),
ADD CONSTRAINT pricing_page_subtitle_color_format
CHECK (page_subtitle_color = '' OR page_subtitle_color ~ '^#[0-9A-Fa-f]{6}$');