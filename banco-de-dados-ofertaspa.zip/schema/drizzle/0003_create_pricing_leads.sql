CREATE TABLE public.pricing_leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_name text NOT NULL CHECK (char_length(plan_name) BETWEEN 1 AND 60),
  name text NOT NULL CHECK (char_length(name) BETWEEN 2 AND 120),
  store_name text NOT NULL CHECK (char_length(store_name) BETWEEN 2 AND 120),
  email text NOT NULL CHECK (char_length(email) BETWEEN 5 AND 160),
  phone text NOT NULL CHECK (char_length(phone) BETWEEN 10 AND 20),
  address text NOT NULL CHECK (char_length(address) BETWEEN 5 AND 240),
  viewed boolean NOT NULL DEFAULT false,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT SELECT, UPDATE, DELETE ON public.pricing_leads TO authenticated;
GRANT ALL ON public.pricing_leads TO service_role;

ALTER TABLE public.pricing_leads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Super admin reads pricing leads"
ON public.pricing_leads
FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'super_admin'));

CREATE POLICY "Super admin updates pricing leads"
ON public.pricing_leads
FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'super_admin'))
WITH CHECK (public.has_role(auth.uid(), 'super_admin'));

CREATE POLICY "Super admin deletes pricing leads"
ON public.pricing_leads
FOR DELETE
TO authenticated
USING (public.has_role(auth.uid(), 'super_admin'));

CREATE INDEX pricing_leads_created_at_idx ON public.pricing_leads (created_at DESC);
CREATE INDEX pricing_leads_duplicate_idx ON public.pricing_leads (email, phone, plan_name, created_at DESC);