ALTER TABLE public.course_links
ADD COLUMN requires_full_access boolean NOT NULL DEFAULT false;

COMMENT ON COLUMN public.course_links.requires_full_access IS
'When true, only authenticated users whose card is visible and has gallery, video, and scheduling enabled may read this link.';

ALTER POLICY course_links_auth_read
ON public.course_links
TO authenticated
USING (
  published
  AND (
    NOT requires_full_access
    OR EXISTS (
      SELECT 1
      FROM public.cards
      WHERE cards.owner_id = auth.uid()
        AND cards.suspended = false
        AND cards.gallery_enabled = true
        AND cards.video_enabled = true
        AND cards.schedule_enabled = true
    )
  )
);