CREATE OR REPLACE FUNCTION public.get_admin_dashboard_metrics()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_catalog
AS $$
DECLARE
  result jsonb;
BEGIN
  IF auth.uid() IS NULL OR NOT public.has_role(auth.uid(), 'super_admin') THEN
    RAISE EXCEPTION 'Acesso restrito ao super admin' USING ERRCODE = '42501';
  END IF;

  SELECT jsonb_build_object(
    'updated_at', now(),
    'database_bytes', pg_database_size(current_database()),
    'media_bytes', (
      SELECT COALESCE(SUM(
        COALESCE(octet_length(image_url), 0) +
        COALESCE(octet_length(thumb_url), 0) +
        COALESCE((SELECT SUM(octet_length(item)) FROM unnest(gallery_images) AS item), 0)
      ), 0)
      FROM public.cards
    ) + (
      SELECT COALESCE(SUM(COALESCE(octet_length(image_url), 0) + COALESCE(octet_length(thumb_url), 0)), 0)
      FROM public.card_schedules
    ) + (
      SELECT COALESCE(SUM(COALESCE(octet_length(cover_image_url), 0) + COALESCE(octet_length(background_image_url), 0) + COALESCE(octet_length(products_icon_url), 0) + COALESCE(octet_length(popup_image_url), 0) + COALESCE(octet_length(user_popup_image_url), 0) + COALESCE((SELECT SUM(octet_length(item)) FROM unnest(about_images) AS item), 0)), 0)
      FROM public.site_settings
    ) + (
      SELECT COALESCE(SUM(COALESCE(octet_length(image_url), 0) + COALESCE(octet_length(thumb_url), 0)), 0)
      FROM public.products
    ) + (
      SELECT COALESCE(SUM(COALESCE(octet_length(image_url), 0) + COALESCE(octet_length(thumb_url), 0)), 0)
      FROM public.raffles
    ) + (
      SELECT COALESCE(SUM(COALESCE(octet_length(thumb_url), 0)), 0)
      FROM public.course_links
    ),
    'profiles_total', (SELECT COUNT(*) FROM public.profiles),
    'users_total', (SELECT COUNT(DISTINCT ur.user_id) FROM public.user_roles ur WHERE ur.role = 'user'),
    'cards_total', (SELECT COUNT(*) FROM public.cards),
    'cards_active', (SELECT COUNT(*) FROM public.cards WHERE NOT suspended),
    'cards_suspended', (SELECT COUNT(*) FROM public.cards WHERE suspended),
    'clients_total', (SELECT COUNT(*) FROM public.clients),
    'registrations_total', (SELECT COUNT(*) FROM public.registrations),
    'registrations_active', (SELECT COUNT(*) FROM public.registrations WHERE end_date IS NULL OR end_date >= CURRENT_DATE),
    'registrations_expired', (SELECT COUNT(*) FROM public.registrations WHERE end_date IS NOT NULL AND end_date < CURRENT_DATE),
    'products_published', (SELECT COUNT(*) FROM public.products WHERE published),
    'raffle_entries_total', (SELECT COUNT(*) FROM public.raffle_entries),
    'scheduled_active', (SELECT COUNT(*) FROM public.card_schedules WHERE active),
    'activity', (
      SELECT COALESCE(jsonb_agg(jsonb_build_object(
        'date', d::date,
        'users', (SELECT COUNT(*) FROM public.profiles p WHERE p.created_at >= d AND p.created_at < d + interval '1 day'),
        'clients', (SELECT COUNT(*) FROM public.clients c WHERE c.created_at >= d AND c.created_at < d + interval '1 day'),
        'registrations', (SELECT COUNT(*) FROM public.registrations r WHERE r.created_at >= d AND r.created_at < d + interval '1 day')
      ) ORDER BY d), '[]'::jsonb)
      FROM generate_series(date_trunc('day', now()) - interval '6 days', date_trunc('day', now()), interval '1 day') d
    )
  ) INTO result;

  RETURN result;
END;
$$;

REVOKE ALL ON FUNCTION public.get_admin_dashboard_metrics() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_admin_dashboard_metrics() TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_admin_dashboard_metrics() TO service_role;
COMMENT ON FUNCTION public.get_admin_dashboard_metrics() IS 'Returns aggregate operational metrics exclusively to authenticated super admins.';