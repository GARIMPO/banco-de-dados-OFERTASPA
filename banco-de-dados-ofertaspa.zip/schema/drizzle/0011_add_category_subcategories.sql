CREATE TABLE public.category_subcategories (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 category_id uuid NOT NULL REFERENCES public.categories(id) ON DELETE CASCADE,
 name text NOT NULL CHECK (length(trim(name)) BETWEEN 1 AND 40),
 sort_order integer NOT NULL DEFAULT 0,
 created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE (category_id, name)
);
GRANT SELECT ON public.category_subcategories TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.category_subcategories TO authenticated;
GRANT ALL ON public.category_subcategories TO service_role;
ALTER TABLE public.category_subcategories ENABLE ROW LEVEL SECURITY;
CREATE POLICY subcategories_public_read ON public.category_subcategories FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY subcategories_admin_manage ON public.category_subcategories FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'super_admin')) WITH CHECK (public.has_role(auth.uid(), 'super_admin'));
CREATE INDEX subcategories_category_idx ON public.category_subcategories(category_id, sort_order);
ALTER TABLE public.cards ADD COLUMN subcategory_id uuid REFERENCES public.category_subcategories(id) ON DELETE SET NULL;
CREATE INDEX cards_subcategory_idx ON public.cards(subcategory_id);
CREATE FUNCTION public.validate_card_subcategory() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
 IF TG_OP = 'UPDATE' AND NEW.category_id IS DISTINCT FROM OLD.category_id AND NEW.subcategory_id IS NOT DISTINCT FROM OLD.subcategory_id THEN
  NEW.subcategory_id := NULL;
 END IF;
 IF NEW.subcategory_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.category_subcategories s WHERE s.id = NEW.subcategory_id AND s.category_id = NEW.category_id) THEN
  RAISE EXCEPTION 'Subcategoria não pertence à categoria escolhida';
 END IF;
 RETURN NEW;
END;
$$;
CREATE TRIGGER cards_validate_subcategory BEFORE INSERT OR UPDATE OF category_id, subcategory_id ON public.cards FOR EACH ROW EXECUTE FUNCTION public.validate_card_subcategory();