ALTER TABLE public.pricing_page_settings
  ADD COLUMN plan_one_payment_url text NOT NULL DEFAULT '',
  ADD COLUMN plan_one_annual_payment_url text NOT NULL DEFAULT '',
  ADD COLUMN plan_two_payment_url text NOT NULL DEFAULT '',
  ADD COLUMN plan_two_annual_payment_url text NOT NULL DEFAULT '',
  ADD COLUMN coupon_plan_one_payment_url text NOT NULL DEFAULT '',
  ADD COLUMN coupon_plan_one_annual_payment_url text NOT NULL DEFAULT '',
  ADD COLUMN coupon_plan_two_payment_url text NOT NULL DEFAULT '',
  ADD COLUMN coupon_plan_two_annual_payment_url text NOT NULL DEFAULT '';

ALTER TABLE public.pricing_page_settings
  ADD CONSTRAINT pricing_payment_urls_https_check CHECK (
    (plan_one_payment_url = '' OR plan_one_payment_url ~ '^https://') AND
    (plan_one_annual_payment_url = '' OR plan_one_annual_payment_url ~ '^https://') AND
    (plan_two_payment_url = '' OR plan_two_payment_url ~ '^https://') AND
    (plan_two_annual_payment_url = '' OR plan_two_annual_payment_url ~ '^https://') AND
    (coupon_plan_one_payment_url = '' OR coupon_plan_one_payment_url ~ '^https://') AND
    (coupon_plan_one_annual_payment_url = '' OR coupon_plan_one_annual_payment_url ~ '^https://') AND
    (coupon_plan_two_payment_url = '' OR coupon_plan_two_payment_url ~ '^https://') AND
    (coupon_plan_two_annual_payment_url = '' OR coupon_plan_two_annual_payment_url ~ '^https://')
  );