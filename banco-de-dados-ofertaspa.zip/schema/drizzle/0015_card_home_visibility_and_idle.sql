ALTER TABLE public.cards ADD COLUMN show_on_home boolean NOT NULL DEFAULT true;
ALTER TABLE public.cards ADD COLUMN image_changed_at timestamptz NOT NULL DEFAULT now();
CREATE OR REPLACE FUNCTION public.cards_touch_image_changed()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF NEW.image_url IS DISTINCT FROM OLD.image_url AND NEW.image_url IS NOT NULL THEN
    NEW.image_changed_at := now();
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER cards_touch_image_changed BEFORE UPDATE ON public.cards
FOR EACH ROW EXECUTE FUNCTION public.cards_touch_image_changed();