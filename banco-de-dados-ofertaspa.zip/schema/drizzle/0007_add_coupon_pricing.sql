ALTER TABLE public.pricing_page_settings
 ADD COLUMN coupon_plan_one_price text NOT NULL DEFAULT '',
 ADD COLUMN coupon_plan_two_price text NOT NULL DEFAULT '';
UPDATE public.pricing_page_settings SET coupon_plan_one_price = plan_one_price, coupon_plan_two_price = plan_two_price;
COMMENT ON COLUMN public.pricing_page_settings.password_enabled IS 'Enables optional coupon access; regular plan prices remain public.';
COMMENT ON COLUMN public.pricing_page_settings.password_hash IS 'Salted PBKDF2 hash of the discount coupon access password.';
