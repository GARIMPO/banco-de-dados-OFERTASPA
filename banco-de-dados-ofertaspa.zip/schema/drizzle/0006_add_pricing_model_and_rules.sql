ALTER TABLE public.pricing_page_settings
  ADD COLUMN model_image_url text,
  ADD COLUMN rules_text text NOT NULL DEFAULT '';
