ALTER TABLE public.pricing_leads
  ADD COLUMN plan_price text,
  ADD COLUMN plan_period text,
  ADD COLUMN coupon_applied boolean;
COMMENT ON COLUMN public.pricing_leads.plan_price IS 'Server-verified plan price at submission; NULL for legacy requests with unknown historical price.';
COMMENT ON COLUMN public.pricing_leads.plan_period IS 'Plan billing period at submission.';
COMMENT ON COLUMN public.pricing_leads.coupon_applied IS 'Whether the server validated coupon access for this request.';