ALTER TABLE public.pricing_page_settings
  ADD COLUMN lead_thank_you_title text NOT NULL DEFAULT 'Cadastro recebido',
  ADD COLUMN lead_thank_you_message text NOT NULL DEFAULT 'Obrigado! Nossa equipe entrará em contato em breve';

COMMENT ON COLUMN public.pricing_page_settings.lead_thank_you_title IS 'Titulo exibido no pop-up apos o cliente enviar o pedido de contratacao';
COMMENT ON COLUMN public.pricing_page_settings.lead_thank_you_message IS 'Mensagem de agradecimento exibida apos o envio do cadastro';