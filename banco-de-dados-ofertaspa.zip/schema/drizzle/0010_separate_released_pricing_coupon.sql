ALTER TABLE public.pricing_page_settings
  ADD COLUMN released_coupon_enabled boolean NOT NULL DEFAULT false,
  ADD COLUMN released_coupon_code text NOT NULL DEFAULT '',
  ADD COLUMN released_coupon_salt text,
  ADD COLUMN released_coupon_hash text;
COMMENT ON COLUMN public.pricing_page_settings.coupon_code IS 'Current private discount coupon, visible only to super admin; replaced in place without history.';
COMMENT ON COLUMN public.pricing_page_settings.coupon_expires_at IS 'Expiry for the independently enabled public released coupon.';
COMMENT ON COLUMN public.pricing_page_settings.released_coupon_code IS 'Current public released coupon, independent of the private discount coupon.';