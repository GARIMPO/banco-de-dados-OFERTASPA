CREATE TABLE public.pricing_page_settings (
  id boolean PRIMARY KEY DEFAULT true CHECK (id),
  page_title text NOT NULL DEFAULT 'Planos para sua loja',
  page_subtitle text NOT NULL DEFAULT 'Escolha a opção ideal para divulgar seus produtos e alcançar mais clientes.',
  plan_one_name text NOT NULL DEFAULT 'Plano Essencial',
  plan_one_price text NOT NULL DEFAULT 'R$ 19,90',
  plan_one_period text NOT NULL DEFAULT 'mensal',
  plan_one_items jsonb NOT NULL DEFAULT '["1 imagem", "2 links: Instagram, Facebook, TikTok, WhatsApp, Website ou Google Maps", "Botão de compartilhamento"]'::jsonb,
  plan_two_name text NOT NULL DEFAULT 'Plano Completo',
  plan_two_price text NOT NULL DEFAULT 'Consulte',
  plan_two_period text NOT NULL DEFAULT 'mensal',
  plan_two_items jsonb NOT NULL DEFAULT '["Até 5 imagens no total", "2 links: Instagram, Facebook, TikTok, WhatsApp, Website ou Google Maps", "Botão de compartilhamento", "+4 imagens extras", "Agendamento de imagens", "Vídeo"]'::jsonb,
  password_enabled boolean NOT NULL DEFAULT false,
  password_salt text,
  password_hash text,
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.pricing_page_settings TO authenticated;
GRANT ALL ON public.pricing_page_settings TO service_role;
ALTER TABLE public.pricing_page_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Super admin manages pricing page"
ON public.pricing_page_settings
FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'super_admin'))
WITH CHECK (public.has_role(auth.uid(), 'super_admin'));
INSERT INTO public.pricing_page_settings (id) VALUES (true);
CREATE TRIGGER set_pricing_page_settings_updated_at
BEFORE UPDATE ON public.pricing_page_settings
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();