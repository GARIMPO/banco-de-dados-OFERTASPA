ALTER TABLE public.site_settings
  ADD COLUMN IF NOT EXISTS privacy_text_color text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS grid_heading text NOT NULL DEFAULT 'Ofertas e lojas de Pouso Alegre';