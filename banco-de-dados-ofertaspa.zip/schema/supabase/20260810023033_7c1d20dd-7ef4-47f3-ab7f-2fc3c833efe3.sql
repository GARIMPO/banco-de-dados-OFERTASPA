ALTER TABLE public.cards
  ADD COLUMN IF NOT EXISTS gallery_enabled boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS gallery_images text[] NOT NULL DEFAULT '{}'::text[];