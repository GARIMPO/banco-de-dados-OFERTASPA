DROP FUNCTION IF EXISTS public.close_card_view(uuid, integer);
DROP TABLE IF EXISTS public.card_views;

CREATE OR REPLACE FUNCTION public.validate_client()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.name := btrim(NEW.name);
  NEW.phone := btrim(NEW.phone);
  NEW.email := btrim(NEW.email);

  IF NEW.owner_id IS NULL OR NEW.owner_id <> auth.uid() THEN
    IF NOT public.has_role(auth.uid(), 'super_admin') THEN
      RAISE EXCEPTION 'Cliente deve pertencer ao usuário autenticado';
    END IF;
  END IF;

  IF length(NEW.name) = 0 OR length(NEW.name) > 120 THEN
    RAISE EXCEPTION 'Nome deve ter entre 1 e 120 caracteres';
  END IF;
  IF length(NEW.phone) > 30 THEN
    RAISE EXCEPTION 'Telefone muito longo';
  END IF;
  IF length(NEW.email) > 160 THEN
    RAISE EXCEPTION 'E-mail muito longo';
  END IF;
  IF length(NEW.email) > 0 AND NEW.email !~* '^[^@\s]+@[^@\s]+\.[a-z]{2,}$' THEN
    RAISE EXCEPTION 'E-mail inválido';
  END IF;
  IF NEW.birth_date IS NOT NULL AND (NEW.birth_date > CURRENT_DATE OR NEW.birth_date < DATE '1900-01-01') THEN
    RAISE EXCEPTION 'Data de aniversário inválida';
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS clients_validate ON public.clients;
CREATE TRIGGER clients_validate
BEFORE INSERT OR UPDATE ON public.clients
FOR EACH ROW EXECUTE FUNCTION public.validate_client();