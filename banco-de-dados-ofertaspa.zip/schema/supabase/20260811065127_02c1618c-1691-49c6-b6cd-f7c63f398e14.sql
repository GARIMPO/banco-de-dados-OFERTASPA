ALTER TABLE public.site_settings
  ADD COLUMN IF NOT EXISTS raffle_bg_color text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS raffle_text_color text NOT NULL DEFAULT '';