ALTER TABLE public.site_settings
  ADD COLUMN IF NOT EXISTS about_cta_enabled boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS about_cta_url text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS support_url text NOT NULL DEFAULT '';