ALTER TABLE public.site_settings
  ADD COLUMN IF NOT EXISTS about_title text NOT NULL DEFAULT 'Quem somos',
  ADD COLUMN IF NOT EXISTS about_body text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS privacy_title text NOT NULL DEFAULT 'Política de privacidade',
  ADD COLUMN IF NOT EXISTS privacy_body text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS footer_text text NOT NULL DEFAULT 'Todos os direitos reservado Garimpo de Ofertas';