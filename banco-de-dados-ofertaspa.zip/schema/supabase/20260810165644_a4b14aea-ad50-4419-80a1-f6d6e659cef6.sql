CREATE TABLE public.course_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL DEFAULT '',
  body text NOT NULL DEFAULT '',
  thumb_url text,
  link_label text,
  link_url text,
  published boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.course_links TO authenticated;
GRANT ALL ON public.course_links TO service_role;

ALTER TABLE public.course_links ENABLE ROW LEVEL SECURITY;

CREATE POLICY course_links_admin_all ON public.course_links FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'super_admin'))
  WITH CHECK (public.has_role(auth.uid(), 'super_admin'));

CREATE POLICY course_links_auth_read ON public.course_links FOR SELECT TO authenticated
  USING (published);

CREATE TRIGGER course_links_set_updated_at BEFORE UPDATE ON public.course_links
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();