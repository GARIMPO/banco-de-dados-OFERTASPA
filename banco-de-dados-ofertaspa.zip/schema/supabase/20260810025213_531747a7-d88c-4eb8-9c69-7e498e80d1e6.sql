ALTER TABLE public.cards
  ADD COLUMN IF NOT EXISTS video_enabled boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS video_url text;

ALTER TABLE public.site_settings
  ADD COLUMN IF NOT EXISTS header_text_color text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS header_font text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS search_text_color text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS search_font text NOT NULL DEFAULT '';

CREATE OR REPLACE FUNCTION public.is_access_expired(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT CASE
    WHEN public.has_role(_user_id, 'super_admin') THEN false
    ELSE EXISTS (
      SELECT 1 FROM public.registrations r
      WHERE r.user_id = _user_id
        AND r.end_date IS NOT NULL
        AND r.end_date < CURRENT_DATE
    )
  END
$$;

GRANT EXECUTE ON FUNCTION public.is_access_expired(uuid) TO authenticated;