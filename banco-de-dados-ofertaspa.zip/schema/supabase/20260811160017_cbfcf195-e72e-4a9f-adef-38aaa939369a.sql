ALTER TABLE public.site_settings
  ADD COLUMN IF NOT EXISTS user_popup_enabled boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS user_popup_title text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS user_popup_body text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS user_popup_image_url text,
  ADD COLUMN IF NOT EXISTS user_popup_link_url text NOT NULL DEFAULT '';