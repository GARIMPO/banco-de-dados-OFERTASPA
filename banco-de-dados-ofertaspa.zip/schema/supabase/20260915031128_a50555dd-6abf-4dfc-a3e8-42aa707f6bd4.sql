ALTER TABLE public.cards ALTER COLUMN slug SET DEFAULT '';

CREATE OR REPLACE FUNCTION public.set_card_slug()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
DECLARE
  base_slug text;
  candidate text;
  suffix integer := 1;
  reserved_slugs text[] := ARRAY['auth', 'painel', 'quem-somos', 'politica-de-privacidade', 'sitemap.xml', 'c', 'loja', 'api'];
BEGIN
  IF NEW.slug IS NOT NULL AND BTRIM(NEW.slug) <> '' THEN
    base_slug := public.slugify_store_name(NEW.slug);
  ELSE
    base_slug := public.slugify_store_name(NEW.title);
  END IF;

  PERFORM pg_advisory_xact_lock(hashtext(base_slug));
  candidate := base_slug;

  WHILE candidate = ANY(reserved_slugs)
     OR EXISTS (SELECT 1 FROM public.cards c WHERE c.slug = candidate AND c.id <> NEW.id)
  LOOP
    suffix := suffix + 1;
    candidate := LEFT(base_slug, GREATEST(1, 80 - LENGTH(suffix::text) - 1)) || '-' || suffix::text;
  END LOOP;

  NEW.slug := candidate;
  RETURN NEW;
END;
$$;