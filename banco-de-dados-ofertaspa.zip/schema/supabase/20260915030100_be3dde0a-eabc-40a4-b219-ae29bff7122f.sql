ALTER TABLE public.cards ADD COLUMN slug text;

CREATE OR REPLACE FUNCTION public.slugify_store_name(_value text)
RETURNS text
LANGUAGE sql
IMMUTABLE
STRICT
SET search_path = public
AS $$
  SELECT COALESCE(
    NULLIF(
      LEFT(
        TRIM(BOTH '-' FROM REGEXP_REPLACE(
          TRANSLATE(LOWER(_value),
            'áàâãäåéèêëíìîïóòôõöúùûüçñýÿ',
            'aaaaaaeeeeiiiiooooouuuucnyy'),
          '[^a-z0-9]+', '-', 'g'
        )),
        80
      ),
      ''
    ),
    'loja'
  )
$$;

CREATE OR REPLACE FUNCTION public.set_card_slug()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
DECLARE
  base_slug text;
  reserved_slugs text[] := ARRAY['auth', 'painel', 'quem-somos', 'politica-de-privacidade', 'sitemap.xml', 'c', 'loja', 'api'];
BEGIN
  IF NEW.slug IS NOT NULL AND BTRIM(NEW.slug) <> '' THEN
    NEW.slug := public.slugify_store_name(NEW.slug);
  ELSE
    base_slug := public.slugify_store_name(NEW.title);
    NEW.slug := base_slug;
  END IF;

  IF NEW.slug = ANY(reserved_slugs)
     OR EXISTS (SELECT 1 FROM public.cards c WHERE c.slug = NEW.slug AND c.id <> NEW.id) THEN
    NEW.slug := LEFT(NEW.slug, 73) || '-' || LEFT(REPLACE(NEW.id::text, '-', ''), 6);
  END IF;

  RETURN NEW;
END;
$$;

CREATE TRIGGER cards_set_slug
BEFORE INSERT OR UPDATE OF slug ON public.cards
FOR EACH ROW EXECUTE FUNCTION public.set_card_slug();

UPDATE public.cards
SET slug = public.slugify_store_name(title)
WHERE slug IS NULL OR BTRIM(slug) = '';

ALTER TABLE public.cards ALTER COLUMN slug SET NOT NULL;
CREATE UNIQUE INDEX cards_slug_key ON public.cards (slug);
CREATE INDEX cards_public_slug_idx ON public.cards (slug) WHERE suspended = false;