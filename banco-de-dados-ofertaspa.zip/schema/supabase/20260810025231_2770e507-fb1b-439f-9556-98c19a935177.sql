REVOKE EXECUTE ON FUNCTION public.is_access_expired(uuid) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.is_access_expired(uuid) FROM anon;
GRANT EXECUTE ON FUNCTION public.is_access_expired(uuid) TO authenticated;