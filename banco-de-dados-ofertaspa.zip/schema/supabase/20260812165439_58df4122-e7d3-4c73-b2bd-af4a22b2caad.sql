ALTER TABLE public.cards ADD COLUMN IF NOT EXISTS schedule_enabled boolean NOT NULL DEFAULT false;

CREATE TABLE public.card_schedules (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  card_id uuid NOT NULL REFERENCES public.cards(id) ON DELETE CASCADE,
  owner_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  slot integer NOT NULL CHECK (slot >= 1 AND slot <= 6),
  scheduled_at timestamptz NOT NULL DEFAULT now(),
  active boolean NOT NULL DEFAULT true,
  image_url text,
  thumb_url text,
  title text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  whatsapp text,
  instagram text,
  facebook text,
  tiktok text,
  website text,
  maps_url text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (card_id, slot)
);

CREATE INDEX card_schedules_card_due_idx ON public.card_schedules (card_id, scheduled_at DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.card_schedules TO authenticated;
GRANT SELECT ON public.card_schedules TO anon;
GRANT ALL ON public.card_schedules TO service_role;

ALTER TABLE public.card_schedules ENABLE ROW LEVEL SECURITY;

CREATE POLICY card_schedules_owner_all ON public.card_schedules
  FOR ALL TO authenticated
  USING (auth.uid() = owner_id)
  WITH CHECK (auth.uid() = owner_id);

CREATE POLICY card_schedules_admin_all ON public.card_schedules
  FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'super_admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'super_admin'::app_role));

CREATE POLICY card_schedules_public_read ON public.card_schedules
  FOR SELECT TO anon, authenticated
  USING (active AND scheduled_at <= now());

CREATE TRIGGER card_schedules_set_updated_at
  BEFORE UPDATE ON public.card_schedules
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();