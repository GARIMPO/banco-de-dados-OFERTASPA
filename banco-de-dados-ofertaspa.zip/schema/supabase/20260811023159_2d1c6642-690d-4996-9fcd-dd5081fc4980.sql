ALTER TABLE public.site_settings
  ADD COLUMN IF NOT EXISTS about_text_color text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS about_font text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS about_images text[] NOT NULL DEFAULT '{}'::text[];