ALTER TABLE public.cards ADD COLUMN IF NOT EXISTS thumb_url text;

CREATE OR REPLACE FUNCTION public.cards_thumb_fallback()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  IF NEW.thumb_url IS NULL OR length(btrim(NEW.thumb_url)) = 0 THEN
    NEW.thumb_url := NEW.image_url;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS cards_thumb_fallback_trg ON public.cards;
CREATE TRIGGER cards_thumb_fallback_trg
BEFORE INSERT OR UPDATE ON public.cards
FOR EACH ROW EXECUTE FUNCTION public.cards_thumb_fallback();

UPDATE public.cards SET thumb_url = image_url WHERE thumb_url IS NULL;