CREATE TABLE public.raffles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL DEFAULT '',
  details text NOT NULL DEFAULT '',
  rules text NOT NULL DEFAULT '',
  image_url text,
  starts_on date,
  ends_on date,
  link_url text NOT NULL DEFAULT '',
  published boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.raffles TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.raffles TO authenticated;
GRANT ALL ON public.raffles TO service_role;

ALTER TABLE public.raffles ENABLE ROW LEVEL SECURITY;

CREATE POLICY raffles_public_read ON public.raffles FOR SELECT USING (published);
CREATE POLICY raffles_admin_all ON public.raffles FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'super_admin')) WITH CHECK (has_role(auth.uid(), 'super_admin'));

CREATE TRIGGER raffles_set_updated_at BEFORE UPDATE ON public.raffles
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.raffle_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  raffle_id uuid NOT NULL REFERENCES public.raffles(id) ON DELETE CASCADE,
  name text NOT NULL,
  ddd text NOT NULL DEFAULT '',
  phone text NOT NULL DEFAULT '',
  email text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX raffle_entries_unique_name ON public.raffle_entries (raffle_id, lower(btrim(name)));
CREATE UNIQUE INDEX raffle_entries_unique_phone ON public.raffle_entries (raffle_id, (regexp_replace(ddd || phone, '\D', '', 'g')));

GRANT INSERT ON public.raffle_entries TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.raffle_entries TO authenticated;
GRANT ALL ON public.raffle_entries TO service_role;

ALTER TABLE public.raffle_entries ENABLE ROW LEVEL SECURITY;

CREATE POLICY raffle_entries_public_insert ON public.raffle_entries FOR INSERT
  WITH CHECK (
    length(btrim(name)) BETWEEN 2 AND 120
    AND length(btrim(phone)) BETWEEN 6 AND 20
    AND length(btrim(ddd)) BETWEEN 2 AND 3
    AND length(btrim(email)) <= 160
    AND EXISTS (SELECT 1 FROM public.raffles r WHERE r.id = raffle_id AND r.published)
  );

CREATE POLICY raffle_entries_admin_all ON public.raffle_entries FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'super_admin')) WITH CHECK (has_role(auth.uid(), 'super_admin'));